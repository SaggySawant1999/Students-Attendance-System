package com.org.dc;
import java.sql.*;
public class DAL {
    private static Connection con = null;
   
    private void connect() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://localhost/attendancesystem","root","");
        } catch (ClassNotFoundException e) {
            System.out.println(e);
        } catch (SQLException e) {
            System.out.println(e);
        }
    }
    public void disconnect() {       
        try {
            con.close();
        } catch (SQLException e) {
            System.out.println(e);
        }

    }

    
    public int executeDML(String sql) {
        int rownumber=0;
        try {
            connect();
            Statement insertStmt = con.createStatement();
            insertStmt.executeUpdate(sql,insertStmt.RETURN_GENERATED_KEYS);
            ResultSet rs= insertStmt.getGeneratedKeys();
            if (rs.next())
            {
              rownumber= rs.getInt(1);
            }
            return rownumber;
        } catch (SQLException e) {
            System.out.println(e);
            return rownumber;
        } finally {
            disconnect();
        }
    }

    public ResultSet executeQuery(String sql) {
        try {
            connect();
            Statement insertStmt = con.createStatement();
            ResultSet rs = insertStmt.executeQuery(sql);
            return rs;
        } catch (SQLException e) {
            System.out.println(e);
            return null;
        }
    }
}
