package com.org.model;
import  java.util.*;
import java.sql.*;
import com.org.dc.DAL;

public class StreamDetails {
    int id;
    String stream_name;
    //id,stream_name

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getStream_name() {
        return stream_name;
    }

    public void setStream_name(String stream_name) {
        this.stream_name = stream_name;
    }
    
    public StreamDetails getOneStream(int id){
        DAL d=new DAL();
        try{
            StreamDetails sd = new StreamDetails();
            ResultSet rs=d.executeQuery("select * from stream_details where id="+id);
            if(rs.next())
            {
                this.setId(rs.getInt("id"));
                this.setStream_name(rs.getString("stream_name"));
                return sd;
            }
            else
            {
                return null;
            }
            
        }catch(Exception e)
        {
            System.out.println(e);
            return null;
        }
        
    }
    public ArrayList<StreamDetails> getallStreamDetails()
    {
        DAL d= new DAL();
        try{
            ArrayList<StreamDetails> al=new ArrayList<StreamDetails>();
             ResultSet rs=d.executeQuery("select * from stream_details");
           while(rs.next())
           {
               StreamDetails sd=new StreamDetails();
               sd.setId(rs.getInt("id"));
                sd.setStream_name(rs.getString("stream_name"));
                al.add(sd);
                System.out.println(rs.getString("stream_name"));
           }
           return al;
        }catch(Exception e)
        {
            System.out.println(e);
            return null;
        }
    }
    public int save(){
        DAL d=new DAL();
        try{
            String sql="insert into stream_details(id,stream_name)"+"values('"+this.getId()+"','"+this.getStream_name()+"')";
                return d.executeDML(sql);
                    }catch(Exception e){
            System.out.println(e);
            return 0;
        }
    }
    public int update(){
        DAL d=new DAL();
        try{
            String sql="update stream_details set id='"+this.getId()+"',stream_name='"+this.getStream_name()+"'";
            return d.executeDML(sql);           
        }catch(Exception e)
        {
            System.out.println(e);
            return 0;
        }
    }
    public int delete(){
        DAL d=new DAL();
        try{
            String sql="delete from stream_details from id="+this.getId();
            return d.executeDML(sql);
        }catch(Exception e){
            System.out.println(e);
            return 0;
        }
    }
    
}
