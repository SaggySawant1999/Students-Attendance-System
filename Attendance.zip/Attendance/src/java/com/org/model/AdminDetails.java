package com.org.model;
import java.sql.*;
import com.org.dc.DAL;
import java.util.*;

public class AdminDetails {
    int id;
    String admin_name;
    String admin_email;
    String admin_password;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getAdmin_name() {
        return admin_name;
    }

    public void setAdmin_name(String admin_name) {
        this.admin_name = admin_name;
    }

    public String getAdmin_email() {
        return admin_email;
    }

    public void setAdmin_email(String admin_email) {
        this.admin_email = admin_email;
    }

    public String getAdmin_password() {
        return admin_password;
    }

    public void setAdmin_password(String admin_password) {
        this.admin_password = admin_password;
    }
    public String checkLogin(String admin_email,String admin_password){
        DAL d=new DAL();
        try{
            ResultSet rs=d.executeQuery("select * from admin_details where admin_email='"+admin_email+"' and admin_password='"+admin_password+"'");
            if(rs.next()){
                this.setAdmin_name(rs.getString("admin_name"));
                this.setId(rs.getInt("id"));
                return rs.getString("admin_name");
            }else
            {
                return null;
            }
        }catch(Exception e)
        {
            System.out.println(e);
            return null;
        }finally{
            d.disconnect();
        }
    }
                                     
}