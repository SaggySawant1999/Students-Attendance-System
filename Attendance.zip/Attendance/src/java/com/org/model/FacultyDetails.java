package com.org.model;
import  java.util.*;
import java.sql.*;
import com.org.dc.DAL;

public class FacultyDetails {
    int id;
    String faculty_name;
    String faculty_email;
    String faculty_contact;
    String faculty_password;
    //id,faculty_name,faculty_email,faculty_contact,faculty_password
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFaculty_name() {
        return faculty_name;
    }

    public void setFaculty_name(String faculty_name) {
        this.faculty_name = faculty_name;
    }

    public String getFaculty_email() {
        return faculty_email;
    }

    public void setFaculty_email(String faculty_email) {
        this.faculty_email = faculty_email;
    }

    public String getFaculty_contact() {
        return faculty_contact;
    }

    public void setFaculty_contact(String faculty_contact) {
        this.faculty_contact = faculty_contact;
    }

    public String getFaculty_password() {
        return faculty_password;
    }

    public void setFaculty_password(String faculty_password) {
        this.faculty_password = faculty_password;
    }
    
    public FacultyDetails getOneFaculty(int id){
        DAL d=new DAL();
        try{
            FacultyDetails ad = new FacultyDetails();
            ResultSet rs=d.executeQuery("select * from faculty_Details");
            if(rs.next())
            {
                //id,faculty_name,faculty_email,faculty_contact,faculty_password
                ad.setId(rs.getInt("id"));
                ad.setFaculty_name(rs.getString("faculty_name"));
                ad.setFaculty_email(rs.getString("faculty_email"));
                ad.setFaculty_contact(rs.getString("faculty_contact"));
                ad.setFaculty_password(rs.getString("faculty_password"));               
            }
            else
            {
                return null;
            }
            
        }catch(Exception e)
        {
            System.out.println(e);
        }
        return null;
    }
    public ArrayList<FacultyDetails> getAllFacultyDetails()
    {
        DAL d= new DAL();
        try{
            ArrayList<FacultyDetails> al=new ArrayList<FacultyDetails>();
             ResultSet rs=d.executeQuery("select * from faculty_Details");
           while(rs.next())
           {
               FacultyDetails ad=new FacultyDetails();
                ad.setId(rs.getInt("id"));
                ad.setFaculty_name(rs.getString("faculty_name"));
                ad.setFaculty_email(rs.getString("faculty_email"));
                ad.setFaculty_contact(rs.getString("faculty_contact"));
                ad.setFaculty_password(rs.getString("faculty_password"));
                al.add(ad);
           }
           return al;
        }catch(Exception e)
        {
            System.out.println(e);
            return null;
        }
    }
    public int save(){
        DAL d=new DAL();
        try{
            String sql="insert into faculty_Details(id,faculty_name,faculty_email,faculty_contact,faculty_password)"+"values('"+this.getId()+"','"+this.getFaculty_name()+"','"+this.getFaculty_email()+"','"+this.getFaculty_contact()+"','"+this.getFaculty_password()+"')";
                return d.executeDML(sql);
                    }catch(Exception e){
            System.out.println(e);
            return 0;
        }
    }
    public int update(){
        DAL d=new DAL();
        try{
            String sql="update faculty_Details set id='"+this.getId()+"',faculty_name='"+this.getFaculty_name()+"',faculty_email='"+this.getFaculty_email()+"',faculty_contact='"+this.getFaculty_contact()+"',faculty_password='"+this.getFaculty_password()+"'";
            return d.executeDML(sql);           
        }catch(Exception e)
        {
            System.out.println(e);
            return 0;
        }
    }
    public int delete(){
        DAL d=new DAL();
        try{
            String sql="delete from faculty_Details from id="+this.getId();
            return d.executeDML(sql);
        }catch(Exception e){
            System.out.println(e);
            return 0;
        }
    }
}
