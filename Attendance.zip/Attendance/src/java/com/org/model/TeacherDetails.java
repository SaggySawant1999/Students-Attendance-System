
package com.org.model;
import  java.util.*;
import java.sql.*;
import com.org.dc.DAL;

public class TeacherDetails{
    int id;
    String name;
    String email;
    String stream;
    String gender;
    String contact;
    String subject_name;
    String password;
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getStream() {
        return stream;
    }

    public void setStream(String stream) {
        this.stream = stream;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getSubject_name() {
        return subject_name;
    }

    public void setSubject_name(String subject_name) {
        this.subject_name = subject_name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    public TeacherDetails getOneTeacher(int id){
        DAL d=new DAL();
        try{
            TeacherDetails sd = new TeacherDetails();
            ResultSet rs=d.executeQuery("select * from teacher_details");
            if(rs.next())
            {
                sd.setId(rs.getInt("id"));
                sd.setName(rs.getString("name"));
                sd.setEmail(rs.getString("email"));
                sd.setStream(rs.getString("stream"));
                sd.setGender(rs.getString("gender"));
                sd.setContact(rs.getString("contact"));
                sd.setSubject_name(rs.getString("subject_name"));
                sd.setPassword(rs.getString("password"));
                return sd;             
            }
            else
            {
                return null;
            }
            
        }catch(Exception e)
        {
            System.out.println(e);
            return null;
        }
        
    }
    public ArrayList<TeacherDetails> getAllTeacherDetails()
    {
        DAL d= new DAL();
        try{
            ArrayList<TeacherDetails> al=new ArrayList<TeacherDetails>();
             ResultSet rs=d.executeQuery("select * from teacher_details");
           while(rs.next())
           {
               TeacherDetails sd=new TeacherDetails();
                sd.setId(rs.getInt("id"));
                sd.setName(rs.getString("name"));
                sd.setEmail(rs.getString("email"));
                sd.setStream(rs.getString("stream"));
                sd.setGender(rs.getString("gender"));
                sd.setContact(rs.getString("contact"));
                sd.setSubject_name(rs.getString("subject_name"));
                sd.setPassword(rs.getString("password"));

               
               
               al.add(sd);
           }
           return al;
        }catch(Exception e)
        {
            System.out.println(e);
            return null;
        }
    }
    public int save(){
        DAL d=new DAL();
        try{
            String sql="insert into teacher_details(id,name,email,stream,gender,contact,subject_name,password)"+"values('"+this.getId()+"','"+this.getName()+"','"+this.getEmail()+"','"+this.getStream()+"','"+this.getGender()+"','"+this.getContact()+"','"+this.getSubject_name()+"','"+this.getPassword()+"')";
                return d.executeDML(sql);
                    }catch(Exception e){
            System.out.println(e);
            return 0;
        }
    }
    public int update(){
        DAL d=new DAL();
        try{
            String sql="update teacher_details set id='"+this.getId()+"',name='"+this.getName()+"',email='"+this.getEmail()+"',stream='"+this.getStream()+"',gender='"+this.getGender()+"',contact='"+this.getContact()+"',subject_name='"+this.getSubject_name()+"',password='"+this.getPassword()+"'";
            return d.executeDML(sql);           
        }catch(Exception e)
        {
            System.out.println(e);
            return 0;
        }
    }
    public int delete(){
        DAL d=new DAL();
        try{
            String sql="delete from teacher_details from id="+this.getId();
            return d.executeDML(sql);
        }catch(Exception e){
            System.out.println(e);
            return 0;
        }
    }

    public String checkLogin(String email,String password){
        DAL d=new DAL();
        try{
            ResultSet rs=d.executeQuery("select * from teacher_details where email='"+email+"' and password='"+password+"'");
            if(rs.next()){
                this.setName(rs.getString("name"));
                this.setId(rs.getInt("id"));
                return rs.getString("name");
            }else
            {
                return null;
            }
        }catch(Exception e)
        {
            System.out.println(e);
            return null;
        }finally{
            d.disconnect();
        }
    }
    }
       