package com.org.model;
import  java.util.*;
import java.sql.*;
import com.org.dc.DAL;

public class SubjectDetails {
    int id;
    String subject_name;
    int stream_id;
    String class_name;
    String semester_name;
    String active_status;
    //id,subject_name,stream_id,class_name,semester_name,active_status

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSubject_name() {
        return subject_name;
    }

    public void setSubject_name(String subject_name) {
        this.subject_name = subject_name;
    }

    public int getStream_id() {
        return stream_id;
    }

    public void setStream_id(int stream_id) {
        this.stream_id = stream_id;
    }

    public String getClass_name() {
        return class_name;
    }

    public void setClass_name(String class_name) {
        this.class_name = class_name;
    }

    public String getSemester_name() {
        return semester_name;
    }

    public void setSemester_name(String semester_name) {
        this.semester_name = semester_name;
    }

    public String getActive_status() {
        return active_status;
    }

    public void setActive_status(String active_status) {
        this.active_status = active_status;
    }
    public SubjectDetails getOneSubject(int id){
        DAL d=new DAL();
        try{
            SubjectDetails sd = new SubjectDetails();
            ResultSet rs=d.executeQuery("select * from subject_details");
            if(rs.next())
            {
                sd.setId(rs.getInt("id"));
                sd.setSubject_name(rs.getString("subject_name"));
                sd.setStream_id(rs.getInt("stream_id"));
                sd.setClass_name(rs.getString("class_name"));
                sd.setSemester_name(rs.getString("semester_name"));
                sd.setActive_status(rs.getString("active_status"));
                return sd;             
            }
            else
            {
                return null;
            }
            
        }catch(Exception e)
        {
            System.out.println(e);
            return null;
        }
        
    }
    public ArrayList<SubjectDetails> getAllSubjectDetails()
    {
        DAL d= new DAL();
        try{
            ArrayList<SubjectDetails> al=new ArrayList<SubjectDetails>();
             ResultSet rs=d.executeQuery("select * from subject_details");
           while(rs.next())
           {
               SubjectDetails sd=new SubjectDetails();
                sd.setId(rs.getInt("id"));
                sd.setSubject_name(rs.getString("subject_name"));
                sd.setStream_id(rs.getInt("stream_id"));
                sd.setClass_name(rs.getString("class_name"));
                sd.setSemester_name(rs.getString("semester_name"));
                sd.setActive_status(rs.getString("active_status"));
                al.add(sd);
           }
           return al;
        }catch(Exception e)
        {
            System.out.println(e);
            return null;
        }
    }
    public int save(){
        DAL d=new DAL();
        try{
            String sql="insert into subject_details(id,subject_name,stream_id,class_name,semester_name,active_status)"+"values('"+this.getId()+"','"+this.getSubject_name()+"','"+this.getStream_id()+"','"+this.getClass_name()+"','"+this.getSemester_name()+"','"+this.getActive_status()+"')";
                return d.executeDML(sql);
                    }catch(Exception e){
            System.out.println(e);
            return 0;
        }
    }
    public int update(){
        DAL d=new DAL();
        try{
            String sql="update subject_details set id='"+this.getId()+"',subject_name='"+this.getSubject_name()+"',stream_id='"+this.getStream_id()+"',class_name='"+this.getClass_name()+"',semester_name='"+this.getSemester_name()+"',active_status='"+this.getActive_status()+"'";
            return d.executeDML(sql);           
        }catch(Exception e)
        {
            System.out.println(e);
            return 0;
        }
    }
    public int delete(){
        DAL d=new DAL();
        try{
            String sql="delete from subject_details from id="+this.getId();
            return d.executeDML(sql);
        }catch(Exception e){
            System.out.println(e);
            return 0;
        }
    }
            
    

       
    
}
