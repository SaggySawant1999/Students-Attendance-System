package com.org.model;
import  java.util.*;
import java.sql.*;
import com.org.dc.DAL;

public class FacultySubjects {
    int id;
    int faculty_id;
    int subject_id;
    //id,faculty_id,subjet_id

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getFaculty_id() {
        return faculty_id;
    }

    public void setFaculty_id(int faculty_id) {
        this.faculty_id = faculty_id;
    }

    public int getSubject_id() {
        return subject_id;
    }

    public void setSubject_id(int subject_id) {
        this.subject_id = subject_id;
    }
      public FacultySubjects getOneSubject(int id){
        DAL d=new DAL();
        try{
            FacultySubjects fs = new FacultySubjects();
            ResultSet rs=d.executeQuery("select * from faculty_subjects");
            if(rs.next())
            {
               fs.setId(rs.getInt("id"));
               fs.setFaculty_id(rs.getInt("faculty_id"));
               fs.setSubject_id(rs.getInt("subject_id"));
               return fs;
                
            }
            else
            {
                return null;
            }
            
        }catch(Exception e)
        {
            System.out.println(e);
            return null;
        }
        
    }
    public ArrayList<FacultySubjects> getallFacultySubjects()
    {
        DAL d= new DAL();
        try{
            ArrayList<FacultySubjects> al=new ArrayList<FacultySubjects>();
             ResultSet rs=d.executeQuery("select * from faculty_subjects");
           while(rs.next())
           {
               FacultySubjects fs=new FacultySubjects();
               fs.setId(rs.getInt("id"));
               fs.setFaculty_id(rs.getInt("faculty_id"));
               fs.setSubject_id(rs.getInt("subject_id"));        
               al.add(fs);
           }
           return al;
        }catch(Exception e)
        {
            System.out.println(e);
            return null;
        }
    }
    public int save(){
        DAL d=new DAL();
        try{
            String sql="insert into faculty_subjects(id,faculty_id,subject_id)"+"values('"+this.getId()+"','"+this.getFaculty_id()+"','"+this.getSubject_id()+"')";
                return d.executeDML(sql);
                    }catch(Exception e){
            System.out.println(e);
            return 0;
        }
    }
    public int update(){
        DAL d=new DAL();
        try{
            String sql="update faculty_subjects set id='"+this.getId()+"',faculty_id='"+this.getFaculty_id()+"',subject_id='"+this.getSubject_id()+"'";
            return d.executeDML(sql);           
        }catch(Exception e)
        {
            System.out.println(e);
            return 0;
        }
    }
    public int delete(){
        DAL d=new DAL();
        try{
            String sql="delete from faculty_subjects from id="+this.getId();
            return d.executeDML(sql);
        }catch(Exception e){
            System.out.println(e);
            return 0;
        }
    }
}
