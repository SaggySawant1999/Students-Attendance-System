package com.org.model;
import  java.util.*;
import java.sql.*;
import com.org.dc.DAL;

public class StudentEnrollment {
    int id;
    int std_id;
    int stream_id;

    
    String academic_year;
    String class_name;
    String div_name;
    int roll_no;
    //id,std_id,academic_year,class_name,div_name,roll_no

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getStd_id() {
        return std_id;
    }

    public void setStd_id(int std_id) {
        this.std_id = std_id;
    }
    public int getStream_id() {
        return stream_id;
    }

    public void setStream_id(int stream_id) {
        this.stream_id = stream_id;
    }

    public String getAcademic_year() {
        return academic_year;
    }

    public void setAcademic_year(String academic_year) {
        this.academic_year = academic_year;
    }

    public String getClass_name() {
        return class_name;
    }

    public void setClass_name(String class_name) {
        this.class_name = class_name;
    }

    public String getDiv_name() {
        return div_name;
    }

    public void setDiv_name(String div_name) {
        this.div_name = div_name;
    }

    public int getRoll_no() {
        return roll_no;
    }

    public void setRoll_no(int roll_no) {
        this.roll_no = roll_no;
    }
    public StudentEnrollment getOneStudent(int id){
        DAL d=new DAL();
        try{
            StudentEnrollment se = new StudentEnrollment();
            ResultSet rs=d.executeQuery("select * from student_enrollment");
            if(rs.next())
            {
                //id,std_id,academic_year,class_name,div_name,roll_no
                se.setId(rs.getInt("id"));
                se.setStd_id(rs.getInt("std_id"));
                se.setStream_id(rs.getInt("stream_id"));
                se.setAcademic_year(rs.getString("academic_year"));
                se.setClass_name(rs.getString("class_name"));
                se.setDiv_name(rs.getString("div_name"));
                se.setRoll_no(rs.getInt("roll_no"));
                return se;
            }
            else
            {
                return null;
            }
            
        }catch(Exception e)
        {
            System.out.println(e);
            return null;
        }
        
    }
    public ArrayList<StudentEnrollment> getAllStudentEnrollment()
    {
        DAL d= new DAL();
        try{
            ArrayList<StudentEnrollment> al=new ArrayList<StudentEnrollment>();
             ResultSet rs=d.executeQuery("select * from student_enrollment");
           while(rs.next())
           {
               StudentEnrollment se=new StudentEnrollment();
                se.setId(rs.getInt("id"));
                se.setStd_id(rs.getInt("std_id"));
                se.setStream_id(rs.getInt("stream_id"));
                se.setAcademic_year(rs.getString("academic_year"));
                se.setClass_name(rs.getString("class_name"));
                se.setDiv_name(rs.getString("div_name"));
                se.setRoll_no(rs.getInt("roll_no"));
                al.add(se);     
           }
           return al;
        }catch(Exception e)
        {
            System.out.println(e);
            return null;
        }
    }
    public int save(){
        DAL d=new DAL();
        try{
            String sql="insert into student_enrollment(id,std_id,stream_id,academic_year,class_name,div_name,roll_no)"+"values('"+this.getId()+"','"+this.getStd_id()+"','"+this.getStream_id()+"','"+this.getAcademic_year()+"','"+this.getClass_name()+"','"+this.getDiv_name()+"','"+this.getRoll_no()+"')";
                return d.executeDML(sql);
                    }catch(Exception e){
            System.out.println(e);
            return 0;
        }
    }
    public int update(){
        DAL d=new DAL();
        try{
            String sql="update student_enrollment set id='"+this.getId()+"',std_id='"+this.getStd_id()+"',stream_id='"+this.getStream_id()+"',academic_year='"+this.getAcademic_year()+"',class_name='"+this.getClass_name()+"'div_name='"+this.getDiv_name()+"',roll_no='"+this.getRoll_no()+"'";
            return d.executeDML(sql);           
        }catch(Exception e)
        {
            System.out.println(e);
            return 0;
        }
    }
    public int delete(){
        DAL d=new DAL();
        try{
            String sql="delete from student_enrollment from id="+this.getId();
            return d.executeDML(sql);
        }catch(Exception e){
            System.out.println(e);
            return 0;
        }
    }
            
    
    
}
