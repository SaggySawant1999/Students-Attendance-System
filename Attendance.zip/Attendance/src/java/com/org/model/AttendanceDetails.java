package com.org.model;
import  java.util.*;
import java.sql.*;
import com.org.dc.DAL;

public class AttendanceDetails {
    int id;
    int lecture_id;
    int enroll_id;
    String attendance_status;
    //id,lecture_id,enroll_id,attendance_status

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getLecture_id() {
        return lecture_id;
    }

    public void setLecture_id(int lecture_id) {
        this.lecture_id = lecture_id;
    }

    public int getEnroll_id() {
        return enroll_id;
    }

    public void setEnroll_id(int enroll_id) {
        this.enroll_id = enroll_id;
    }

    public String getAttendance_status() {
        return attendance_status;
    }

    public void setAttendance_status(String attendance_status) {
        this.attendance_status = attendance_status;
    }
    
    public AttendanceDetails getOneStudent(int id){
        DAL d=new DAL();
        try{
            AttendanceDetails ad = new AttendanceDetails();
            ResultSet rs=d.executeQuery("select * from attendance_details");
            if(rs.next())
            {
                ad.setId(rs.getInt("id"));
                ad.setEnroll_id(rs.getInt("enroll_id"));
                ad.setAttendance_status(rs.getString("attendance_status"));
                ad.setLecture_id(rs.getInt("lecture_id"));
                return ad;
            }
            else
            {
                return null;
            }
            
        }catch(Exception e)
        {
            System.out.println(e);
            return null;
        }
        
    }
    public ArrayList<AttendanceDetails> getAllAttendanceDetailses()
    {
        DAL d= new DAL();
        try{
            ArrayList<AttendanceDetails> al=new ArrayList<AttendanceDetails>();
             ResultSet rs=d.executeQuery("select * from attendance_details");
           while(rs.next())
           {
               AttendanceDetails ad=new AttendanceDetails();
               ad.setId(rs.getInt("id"));
               ad.setEnroll_id(rs.getInt("enroll_id"));
               ad.setAttendance_status(rs.getString("attendance_status"));
               ad.setLecture_id(rs.getInt("lecture_id"));
               al.add(ad);
           }
           return al;
        }catch(Exception e)
        {
            System.out.println(e);
            return null;
        }
    }
    public int save(){
        DAL d=new DAL();
        try{
            String sql="insert into attendance_details(id,lecture_id,enroll_id,attendance_status)"+"values('"+this.getId()+"','"+this.getEnroll_id()+"','"+this.getLecture_id()+"','"+this.getAttendance_status()+"')";
                return d.executeDML(sql);
                    }catch(Exception e){
            System.out.println(e);
            return 0;
        }
    }
    public int update(){
        DAL d=new DAL();
        try{
            String sql="update attendance_details set id='"+this.getId()+"',lecture_id='"+this.getLecture_id()+"',enroll_id='"+this.getEnroll_id()+"',attendance_status='"+this.getAttendance_status()+"'";
            return d.executeDML(sql);           
        }catch(Exception e)
        {
            System.out.println(e);
            return 0;
        }
    }
    public int delete(){
        DAL d=new DAL();
        try{
            String sql="delete from attendance_details from id="+this.getId();
            return d.executeDML(sql);
        }catch(Exception e){
            System.out.println(e);
            return 0;
        }
    }
            
    
}
