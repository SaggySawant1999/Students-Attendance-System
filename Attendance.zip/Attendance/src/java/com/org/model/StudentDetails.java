package com.org.model;
import  java.util.*;
import java.sql.*;
import com.org.dc.DAL;

public class StudentDetails {
    int id;
    String reg_year;
    int stream_id;
    String std_name;
    int prn_no;
    String std_gender;
    String std_contact;
    String std_email;
    String std_pass;
    //id,reg_year,stream_id,std_name,prn_no,std_gender,std_contact,std_email

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getReg_year() {
        return reg_year;
    }

    public void setReg_year(String reg_year) {
        this.reg_year = reg_year;
    }

    public int getStream_id() {
        return stream_id;
    }

    public void setStream_id(int stream_id) {
        this.stream_id = stream_id;
    }

    public String getStd_name() {
        return std_name;
    }

    public void setStd_name(String std_name) {
        this.std_name = std_name;
    }

    public int getPrn_no() {
        return prn_no;
    }

    public void setPrn_no(int prn_no) {
        this.prn_no = prn_no;
    }

    public String getStd_gender() {
        return std_gender;
    }

    public void setStd_gender(String std_gender) {
        this.std_gender = std_gender;
    }

    public String getStd_contact() {
        return std_contact;
    }

    public void setStd_contact(String std_contact) {
        this.std_contact = std_contact;
    }

    public String getStd_email() {
        return std_email;
    }

    public void setStd_email(String std_email) {
        this.std_email = std_email;
    }
    public String getStd_pass() {
        return std_pass;
    }

    public void setStd_pass(String std_pass) {
        this.std_pass = std_pass;
    }
    
    
    public String checkLogin(String std_email,String std_pass){
        DAL d=new DAL();
        try{
            ResultSet rs=d.executeQuery("select * from students_details where std_email='"+std_email+"' and std_pass='"+std_pass+"'");
            if(rs.next()){
                this.setStd_name(rs.getString("name"));
                this.setId(rs.getInt("id"));
                return rs.getString("name");
            }else
            {
                return null;
            }
        }catch(Exception e)
        {
            System.out.println(e);
            return null;
        }finally{
            d.disconnect();
        }
    }
    
    
    
    
    

    public StudentDetails getOneStudent(int id){
        DAL d=new DAL();
        try{
            
            ResultSet rs=d.executeQuery("select * from students_details where id="+id);
            if(rs.next())
            {
                StudentDetails sd=new StudentDetails();
            //id,reg_year,stream_id,std_name,prn_no,std_gender,std_contact,std_email
                this.setId(rs.getInt("id"));
                this.setReg_year(rs.getString("reg_year"));
                this.setStream_id(rs.getInt("stream_id"));
                this.setStd_name(rs.getString("std_name"));
                this.setPrn_no(rs.getInt("prn_no"));
                this.setStd_gender(rs.getString("std_gender"));
                this.setStd_contact(rs.getString("std_contact"));
                this.setStd_email(rs.getString("std_email"));
                this.setStd_pass(rs.getString("std_pass"));
                return sd;          
            }
            else
            {
                return null;
            }
            
        }catch(Exception e)
        {
            System.out.println(e);
            return null;
        }
        
    }
    public ArrayList<StudentDetails> getallStudentDetailses()
    {
        DAL d= new DAL();
        try{
            ArrayList<StudentDetails> al=new ArrayList<StudentDetails>();
             ResultSet rs=d.executeQuery("select * from students_details");
           while(rs.next())
           {
               StudentDetails sd=new StudentDetails();
               sd.setId(rs.getInt("id"));
                sd.setReg_year(rs.getString("reg_year"));
                sd.setStream_id(rs.getInt("stream_id"));
                sd.setStd_name(rs.getString("std_name"));
                sd.setPrn_no(rs.getInt("prn_no"));
                sd.setStd_gender(rs.getString("std_gender"));
                sd.setStd_contact(rs.getString("std_contact"));
                sd.setStd_email(rs.getString("std_email"));
                sd.setStd_pass(rs.getString("std_pass"));
                al.add(sd);         
           }
           return al;
        }catch(Exception e)
        {
            System.out.println(e);
            return null;
        }
    }
    public int save(){
        DAL d=new DAL();
        try{
            String sql="insert into students_details(id,reg_year,stream_id,std_name,prn_no,std_gender,std_contact,std_email,std_pass)"+"values('"+this.getId()+"','"+this.getReg_year()+"','"+this.getStream_id()+"','"+this.getStd_name()+"','"+this.getPrn_no()+"','"+this.getStd_gender()+"','"+this.getStd_contact()+"','"+this.getStd_email()+"','"+this.getStd_pass()+"')";
                return d.executeDML(sql);
                    }catch(Exception e){
            System.out.println(e);
            return 0;
        }
    }
    public int update(){
        DAL d=new DAL();
        try{
            String sql="update students_details set id='"+this.getId()+"',reg_year='"+this.getReg_year()+"',stream_id='"+this.getStream_id()+"',std_name='"+this.getStd_name()+"',prn_no='"+this.getPrn_no()+"',std_gender='"+this.getStd_gender()+"',std_contact='"+this.getStd_contact()+"',std_email='"+this.getStd_email()+"',std_pass='"+this.getStd_pass()+"'";
            return d.executeDML(sql);           
        }catch(Exception e)
        {
            System.out.println(e);
            return 0;
        }
    }
    public int delete(){
        DAL d=new DAL();
        try{
            String sql="delete from students_details from id="+this.getId();
            return d.executeDML(sql);
        }catch(Exception e){
            System.out.println(e);
            return 0;
        }
    }

    public void setReg_year(int reg_year) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}