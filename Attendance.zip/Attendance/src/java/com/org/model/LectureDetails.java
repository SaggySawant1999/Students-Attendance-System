package com.org.model;
import  java.util.*;
import java.sql.*;
import com.org.dc.DAL;

public class LectureDetails {
    int id;
    String lecture_date;
    String lecture_from;
    String lecture_from_admin;
    String lecture_till;
    String lecture_till_admin;
    String total_lectures;
    String total_lectures_admin;
    int faculty_id;
    int subject_id;
    String academic_year;
    String div_name;
    String lecture_status;
    String confirm_status;
    //id,lecture_date,lecture_from,lecture_from_admin,lecture_till,lecture_till_admin,total_lectures,total_lectures_admin,faculty_id,subject_id,academic_year,div_name,lecture_status,confirm_status

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getLecture_date() {
        return lecture_date;
    }

    public void setLecture_date(String lecture_date) {
        this.lecture_date = lecture_date;
    }

    public String getLecture_from() {
        return lecture_from;
    }

    public void setLecture_from(String lecture_from) {
        this.lecture_from = lecture_from;
    }

    public String getLecture_from_admin() {
        return lecture_from_admin;
    }

    public void setLecture_from_admin(String lecture_from_admin) {
        this.lecture_from_admin = lecture_from_admin;
    }

    public String getLecture_till() {
        return lecture_till;
    }

    public void setLecture_till(String lecture_till) {
        this.lecture_till = lecture_till;
    }

    public String getLecture_till_admin() {
        return lecture_till_admin;
    }

    public void setLecture_till_admin(String lecture_till_admin) {
        this.lecture_till_admin = lecture_till_admin;
    }

    public String getTotal_lectures() {
        return total_lectures;
    }

    public void setTotal_lectures(String total_lectures) {
        this.total_lectures = total_lectures;
    }

    public String getTotal_lectures_admin() {
        return total_lectures_admin;
    }

    public void setTotal_lectures_admin(String total_lectures_admin) {
        this.total_lectures_admin = total_lectures_admin;
    }

    public int getFaculty_id() {
        return faculty_id;
    }

    public void setFaculty_id(int faculty_id) {
        this.faculty_id = faculty_id;
    }

    public int getSubject_id() {
        return subject_id;
    }

    public void setSubject_id(int subject_id) {
        this.subject_id = subject_id;
    }

    public String getAcademic_year() {
        return academic_year;
    }

    public void setAcademic_year(String academic_year) {
        this.academic_year = academic_year;
    }

    public String getDiv_name() {
        return div_name;
    }

    public void setDiv_name(String div_name) {
        this.div_name = div_name;
    }

    public String getLecture_status() {
        return lecture_status;
    }

    public void setLecture_status(String lecture_status) {
        this.lecture_status = lecture_status;
    }

    public String getConfirm_status() {
        return confirm_status;
    }

    public void setConfirm_status(String confirm_status) {
        this.confirm_status = confirm_status;
    }
    
    public LectureDetails getOneLecture(int id){
        DAL d=new DAL();
        try{
            LectureDetails ld = new LectureDetails();
            ResultSet rs=d.executeQuery("select * from lecture_details");
            if(rs.next())
            {
            //id,lecture_date,lecture_from,lecture_from_admin,lecture_till,lecture_till_admin,total_lectures,total_lectures_admin,faculty_id,subject_id,academic_year,div_name,lecture_status,confirm_status    
           ld.setId(rs.getInt("id"));
           ld.setLecture_date(rs.getString("lecture_date"));
           ld.setLecture_from(rs.getString("lecture_from"));
           ld.setLecture_from_admin(rs.getString("lecture_from_admin"));
           ld.setLecture_till(rs.getString("lecture_till"));
           ld.setLecture_till_admin(rs.getString("lecture_till_admin"));
           ld.setTotal_lectures(rs.getString("total_lectures"));
           ld.setTotal_lectures_admin(rs.getString("total_lectures_admin"));
           ld.setFaculty_id(rs.getInt("faculty_id"));
           ld.setSubject_id(rs.getInt("subject_id"));
           ld.setAcademic_year(rs.getString("academic_year"));
           ld.setDiv_name(rs.getString("div_name"));
           ld.setConfirm_status(rs.getString("confirm_status"));
           ld.setConfirm_status(rs.getString("confirm_status"));
           return ld;               
            }
            else
            {
                return null;
            }
            
        }catch(Exception e)
        {
            System.out.println(e);
           
        }
        return null;
        
    }
    public ArrayList<LectureDetails> getallLectureDetails()
    {
        DAL d= new DAL();
        try{
            ArrayList<LectureDetails> al=new ArrayList<LectureDetails>();
             ResultSet rs=d.executeQuery("select * from lecture_details");
           while(rs.next())
           {
               LectureDetails ld=new LectureDetails();
               //id,lecture_date,lecture_from,lecture_from_admin,lecture_till,lecture_till_admin,total_lectures,total_lectures_admin,faculty_id,subject_id,academic_year,div_name,lecture_status,confirm_status    
           ld.setId(rs.getInt("id"));
           ld.setLecture_date(rs.getString("lecture_date"));
           ld.setLecture_from(rs.getString("lecture_from"));
           ld.setLecture_from_admin(rs.getString("lecture_from_admin"));
           ld.setLecture_till(rs.getString("lecture_till"));
           ld.setLecture_till_admin(rs.getString("lecture_till_admin"));
           ld.setTotal_lectures(rs.getString("total_lectures"));
           ld.setTotal_lectures_admin(rs.getString("total_lectures_admin"));
           ld.setFaculty_id(rs.getInt("faculty_id"));
           ld.setSubject_id(rs.getInt("subject_id"));
           ld.setAcademic_year(rs.getString("academic_year"));
           ld.setDiv_name(rs.getString("div_name"));
           ld.setConfirm_status(rs.getString("confirm_status"));
           ld.setConfirm_status(rs.getString("confirm_status"));
           al.add(ld);
           }
           return al;
        }catch(Exception e)
        {
            System.out.println(e);
            return null;
        }
    }
    public int save(){
        DAL d=new DAL();
        try{
            String sql="insert into lecture_details(id,lecture_date,lecture_from,lecture_from_admin,lecture_till,lecture_till_admin,total_lectures,total_lectures_admin,faculty_id,subject_id,academic_year,div_name,lecture_status,confirm_status)"+"values('"+this.getId()+"','"+this.getLecture_date()+"','"+this.getLecture_from()+"','"+this.getLecture_from_admin()+"','"+this.getLecture_till()+"','"+this.getLecture_till_admin()+"','"+this.getTotal_lectures()+"','"+this.getTotal_lectures_admin()+"','"+this.getFaculty_id()+"','"+this.getSubject_id()+"','"+this.getAcademic_year()+"','"+this.getDiv_name()+"','"+this.getLecture_status()+"','"+this.getConfirm_status()+"')";
                return d.executeDML(sql);
                    }catch(Exception e){
            System.out.println(e);
            return 0;
        }
    }
    public int update(){
        DAL d=new DAL();
        try{
            String sql="update lecture_details set id='"+this.getId()+"',lecture_date='"+this.getLecture_date() +"',lecture_from='"+this.getLecture_from()+"',lecture_from_admin='"+this.getLecture_from_admin()+"',lecture_till='"+this.getLecture_till()+"',lecture_till_admin='"+this.getLecture_till_admin()+"',total_lectures='"+this.getTotal_lectures()+"',total_lectures_admin='"+this.getTotal_lectures_admin()+"',faculty_id='"+this.getFaculty_id()+"',subject_id='"+this.getSubject_id()+"',academic_year='"+this.getAcademic_year()+"',div_name='"+this.getDiv_name()+"',lecture_status='"+this.getLecture_status()+"',confirm_status='"+this.getConfirm_status()+"'";
            return d.executeDML(sql);           
        }catch(Exception e)
        {
            System.out.println(e);
            return 0;
        }
    }
    public int delete(){
        DAL d=new DAL();
        try{
            String sql="delete from lecture_details from id="+this.getId();
            return d.executeDML(sql);
        }catch(Exception e){
            System.out.println(e);
            return 0;
        }
    }
    
    
}
