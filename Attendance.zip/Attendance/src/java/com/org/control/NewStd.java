package com.org.control;
import com.org.model.StudentDetails;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class NewStd extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
             String reg_year=request.getParameter("reg_year");
            int stream_id=Integer.parseInt(request.getParameter("stream_id"));
            String std_name=request.getParameter("std_name");
            int prn_no=Integer.parseInt(request.getParameter("prn_no"));
            String std_gender=request.getParameter("std_gender");
            String std_contact=request.getParameter("std_contact");
            String std_email=request.getParameter("std_email");
            String std_pass=request.getParameter("std_pass");
            
            
            StudentDetails sd=new StudentDetails();
            sd.setReg_year(reg_year);
            sd.setStream_id(stream_id);
            sd.setStd_name(std_name);
            sd.setPrn_no(prn_no);
            sd.setStd_gender(std_gender);
            sd.setStd_contact(std_contact);
            sd.setStd_email(std_email);
            sd.setStd_pass(std_pass);
            sd.save();
            response.sendRedirect("newstudentreg.jsp");           
        }catch(Exception e)
        {
            System.out.println(e);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
